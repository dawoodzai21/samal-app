# Nonprofit Accounting App — Cosmos DB + Microsoft Entra ID (Azure Static Web Apps Free)

A minimal double-entry accounting app for small nonprofits.

- **Azure Static Web Apps (Free plan)** hosts React + a managed Azure Functions API.
- **Azure Cosmos DB (Free Tier, provisioned throughput)** stores accounts and journal entries.
- **Microsoft Entra ID sign-in** via SWA managed auth; routes gated by roles **member** (read) and **treasurer** (post).

> **Defaults based on your preferences**
> - Fund accounting: **disabled** (fields removed from UI)
> - **Currencies**: primary **USD**, secondary **AFN** (display-only toggle; no FX conversion in MVP)
> - Fiscal year start: **January 1**

---

## 1) Azure resources (all free-tier friendly)

1. **Cosmos DB account (NoSQL API) with _Free Tier_ enabled**
   - Create account → Capacity mode: **Provisioned throughput** (not Serverless).
   - Enable **Free Tier** during creation (first **1000 RU/s** and **25 GB** storage are free per account).
   - Create database **`np-accounting`** with **shared throughput** (recommend **400–1000 RU/s** to stay within free tier). Containers are created on first run if missing.
2. **Static Web App (Free plan)**
   - Connect to your GitHub repo.
   - Build config: **App** `frontend`, **API** `api`, **Output** `dist`.
3. **App settings (SWA → Configuration → Application settings)**
   - `COSMOS_DB_ENDPOINT` = *your Cosmos DB endpoint*
   - `COSMOS_DB_KEY` = *primary key*
   - (Optional) `COSMOS_DB_DATABASE` = `np-accounting`

> **Note**: Free Tier isn’t available on serverless Cosmos DB accounts. Use provisioned throughput; a shared database at up to **1000 RU/s** remains free on Free Tier accounts. See Microsoft docs.  
> We also gate routes and parse the **`X-MS-CLIENT-PRINCIPAL`** header to enforce roles.

---

## 2) Enable Microsoft Entra ID sign-in & roles (SWA managed auth)

- The app ships with `/login` → `/.auth/login/aad` and `/logout` → `/.auth/logout` routes.
- **Routes**: All `/api/*` require **authenticated** users; `POST` to `/api/accounts` and `/api/journal` require role **treasurer**.
- Assign users to custom roles (e.g., `member`, `treasurer`) using **Static Web Apps → Roles** (invitations) or automate in Standard plan via roles function.

---

## 3) Local dev

```bash
# Frontend
cd frontend
npm install
npm run dev

# API deps
cd ../api
npm install
```

> For API calls locally, deploy once to SWA or mock the endpoints.

---

## 4) Deploy

Use the Azure Portal to create the Static Web App and connect your GitHub repo (this repo). The portal creates the GitHub Actions workflow. After the resource exists, add the **Cosmos** app settings (`COSMOS_DB_ENDPOINT`, `COSMOS_DB_KEY`) and re-run the workflow.

---

## 5) Data model (Cosmos DB)

- **Database**: `np-accounting` (shared throughput)
- **Containers**:
  - `Accounts` — partition key: `/code`
  - `Journal` — partition key: `/id`
  - `JournalLines` — partition key: `/journalId`

**Trial Balance** computes sums by account up to `asOf` date. Normal balance: Assets/Expenses debit, others credit.

---

## 6) Currency & FY
- UI default currency = **USD**; switcher includes **AFN** (no conversion in MVP).
- Fiscal year = **calendar year** (Jan 1–Dec 31). Reports use selected date filters.

---

## 7) Roadmap
- FX conversion and multi-currency actuals (USD ↔ AFN) with daily rates.
- Donors/receipts & annual statements.
- Budget vs. actual; fund/grant reporting when needed.
- Export (CSV/Excel) and audit log.
