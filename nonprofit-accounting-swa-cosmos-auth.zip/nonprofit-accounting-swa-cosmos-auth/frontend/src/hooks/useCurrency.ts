import { useState } from 'react'

type Curr = 'USD'|'AFN'
export default function useCurrency(){
  const [currency, setCurrency] = useState<Curr>('USD')
  function format(n: number){
    return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(n)
  }
  return { currency, setCurrency, format }
}
