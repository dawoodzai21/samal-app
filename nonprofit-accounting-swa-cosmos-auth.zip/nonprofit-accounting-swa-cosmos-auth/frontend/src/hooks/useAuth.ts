import { useEffect, useState } from 'react'

export type ClientPrincipal = {
  identityProvider: string
  userId: string
  userDetails: string
  userRoles: string[]
}

export default function useAuth(){
  const [user, setUser] = useState<ClientPrincipal | null>(null)
  const loginUrl = '/.auth/login/aad'
  const logoutUrl = '/.auth/logout'

  useEffect(()=>{
    fetch('/.auth/me').then(async r=>{
      const data = await r.json()
      setUser(data?.clientPrincipal || null)
    }).catch(()=> setUser(null))
  }, [])

  return { user, loginUrl, logoutUrl }
}
