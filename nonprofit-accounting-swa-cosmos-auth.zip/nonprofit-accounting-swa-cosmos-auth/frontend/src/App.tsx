import { Link, Route, Routes, Navigate } from 'react-router-dom'
import Accounts from './pages/Accounts'
import Journal from './pages/Journal'
import Reports from './pages/Reports'
import useAuth from './hooks/useAuth'
import useCurrency from './hooks/useCurrency'

export default function App() {
  const { user, loginUrl, logoutUrl } = useAuth()
  const { currency, setCurrency, format } = useCurrency()

  return (
    <div>
      <header>
        <nav>
          <Link to="/">Dashboard</Link>
          <Link to="/accounts">Accounts</Link>
          <Link to="/journal">Journal</Link>
          <Link to="/reports">Reports</Link>
        </nav>
        <div>
          <select value={currency} onChange={e=>setCurrency(e.target.value as any)}>
            <option value="USD">USD</option>
            <option value="AFN">AFN</option>
          </select>
          {user ? (
            <>
              <span style={{marginLeft:8, marginRight:8}}>Hello, {user.userDetails}</span>
              <a href={logoutUrl} style={{color:'#fff'}}>Logout</a>
            </>
          ) : (
            <a href={loginUrl} style={{color:'#fff'}}>Login</a>
          )}
        </div>
      </header>
      <div className="container">
        <Routes>
          <Route path="/" element={<div>Welcome to the Nonprofit Accounting App</div>} />
          <Route path="/accounts" element={<Accounts format={format} user={user} />} />
          <Route path="/journal" element={<Journal format={format} user={user} />} />
          <Route path="/reports" element={<Reports format={format} />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
    </div>
  )
}
