import { useEffect, useState } from 'react'

export default function Reports({ format }: { format: (n:number)=>string }){
  type TBRow = { accountCode: string; accountName: string; debit: number; credit: number; balance: number }
  const [asOf, setAsOf] = useState<string>(()=> new Date().toISOString().slice(0,10))
  const [rows, setRows] = useState<TBRow[]>([])

  async function load(){
    const res = await fetch('/api/reports-trialbalance?asOf=' + asOf)
    setRows(await res.json())
  }

  useEffect(()=>{ load() }, [asOf])

  const totalDebit = rows.reduce((s,r)=> s + r.debit, 0)
  const totalCredit = rows.reduce((s,r)=> s + r.credit, 0)

  return (
    <div>
      <h2>Trial Balance</h2>
      <label>As of: <input type="date" value={asOf} onChange={e=>setAsOf(e.target.value)} /></label>
      <table>
        <thead><tr><th>Account</th><th>Name</th><th className='right'>Debit</th><th className='right'>Credit</th><th className='right'>Balance</th></tr></thead>
        <tbody>
          {rows.map(r=> (
            <tr key={r.accountCode}>
              <td>{r.accountCode}</td>
              <td>{r.accountName}</td>
              <td className='right'>{format(r.debit)}</td>
              <td className='right'>{format(r.credit)}</td>
              <td className='right'>{format(r.balance)}</td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr><td></td><td><b>Totals</b></td><td className='right'><b>{format(totalDebit)}</b></td><td className='right'><b>{format(totalCredit)}</b></td><td></td></tr>
        </tfoot>
      </table>
    </div>
  )
}
