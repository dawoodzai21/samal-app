import { useEffect, useState } from 'react'
import type { ClientPrincipal } from '../hooks/useAuth'

export default function Accounts({ format, user }: { format: (n:number)=>string, user: ClientPrincipal|null }) {
  type Account = { code: string; name: string; type: string; isActive?: boolean }
  const [accounts, setAccounts] = useState<Account[]>([])
  const [form, setForm] = useState<Account>({ code: '', name: '', type: 'Asset', isActive: true })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function load() {
    setLoading(true)
    const res = await fetch('/api/accounts')
    const data = await res.json()
    setAccounts(data)
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  async function addAccount(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    try {
      const res = await fetch('/api/accounts', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form)
      })
      if (!res.ok) throw new Error(await res.text())
      setForm({ code: '', name: '', type: 'Asset', isActive: true })
      await load()
    } catch (err: any) {
      setError(err.message)
    }
  }

  const canPost = !!user && (user.userRoles.includes('treasurer') || user.userRoles.includes('administrator'))

  return (
    <div>
      <h2>Chart of Accounts</h2>
      {canPost && (
        <form onSubmit={addAccount}>
          <input placeholder="Code" value={form.code} onChange={e=>setForm({...form, code:e.target.value})} required />
          <input placeholder="Name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} required />
          <select value={form.type} onChange={e=>setForm({...form, type:e.target.value})}>
            {['Asset','Liability','Equity','Income','Expense'].map(t=> <option key={t} value={t}>{t}</option>)}
          </select>
          <button type="submit">Add</button>
        </form>
      )}
      {!canPost && <p style={{opacity:0.7}}>Sign in as <b>treasurer</b> to add accounts.</p>}
      {error && <div style={{color:'crimson'}}>{error}</div>}
      {loading ? <div>Loading...</div> : (
        <table>
          <thead><tr><th>Code</th><th>Name</th><th>Type</th><th>Active</th></tr></thead>
          <tbody>
            {accounts.map(a=> (
              <tr key={a.code}><td>{a.code}</td><td>{a.name}</td><td>{a.type}</td><td>{a.isActive?'Yes':'No'}</td></tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}
