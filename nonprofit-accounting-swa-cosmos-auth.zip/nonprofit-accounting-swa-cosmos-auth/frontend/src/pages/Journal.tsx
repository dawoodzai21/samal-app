import { useEffect, useState } from 'react'
import type { ClientPrincipal } from '../hooks/useAuth'

type Account = { code: string; name: string; type: string }

type Line = { accountCode: string; debit?: number; credit?: number; memo?: string }

export default function Journal({ format, user }: { format: (n:number)=>string, user: ClientPrincipal|null }) {
  const [accounts, setAccounts] = useState<Account[]>([])
  const [date, setDate] = useState<string>(() => new Date().toISOString().slice(0,10))
  const [memo, setMemo] = useState('')
  const [lines, setLines] = useState<Line[]>([{accountCode:'', debit:0, credit:0},{accountCode:'', debit:0, credit:0}])
  const [message, setMessage] = useState<string>('')
  const [error, setError] = useState<string>('')

  useEffect(() => { (async()=>{
    const res = await fetch('/api/accounts');
    setAccounts(await res.json())
  })() }, [])

  function updateLine(idx: number, patch: Partial<Line>) {
    setLines(ls => ls.map((l,i)=> i===idx? {...l, ...patch}: l))
  }

  function addLine(){ setLines(ls => [...ls, {accountCode:'', debit:0, credit:0}]) }

  async function submit(e: React.FormEvent){
    e.preventDefault()
    setMessage(''); setError('')
    const payload = { date, memo, lines: lines.map(l=> ({...l, debit: Number(l.debit)||0, credit: Number(l.credit)||0})) }
    const res = await fetch('/api/journal', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) })
    if (res.ok){ setMessage('Journal entry posted.'); setLines([{accountCode:'', debit:0, credit:0},{accountCode:'', debit:0, credit:0}]); setMemo('') }
    else { setError(await res.text()) }
  }

  const totalDebit = lines.reduce((s,l)=> s + (Number(l.debit)||0),0)
  const totalCredit = lines.reduce((s,l)=> s + (Number(l.credit)||0),0)

  const canPost = !!user && (user.userRoles.includes('treasurer') || user.userRoles.includes('administrator'))

  return (
    <div>
      <h2>Post Journal Entry</h2>
      {!canPost && <p style={{opacity:0.7}}>Sign in as <b>treasurer</b> to post entries.</p>}
      <form onSubmit={submit}>
        <div>
          <label>Date: <input type="date" value={date} onChange={e=>setDate(e.target.value)} /></label>
          <label> Memo: <input value={memo} onChange={e=>setMemo(e.target.value)} /></label>
        </div>
        {lines.map((l,idx)=> (
          <div key={idx}>
            <select value={l.accountCode} onChange={e=>updateLine(idx,{accountCode:e.target.value})}>
              <option value="">-- account --</option>
              {accounts.map(a=> <option key={a.code} value={a.code}>{a.code} - {a.name}</option>)}
            </select>
            <input type="number" step="0.01" placeholder="Debit" value={l.debit ?? 0} onChange={e=>updateLine(idx,{debit: Number(e.target.value)})} />
            <input type="number" step="0.01" placeholder="Credit" value={l.credit ?? 0} onChange={e=>updateLine(idx,{credit: Number(e.target.value)})} />
            <input placeholder="Memo (optional)" value={l.memo || ''} onChange={e=>updateLine(idx,{memo: e.target.value})} />
          </div>
        ))}
        <button type="button" onClick={addLine}>+ Add line</button>
        <div><b>Totals</b> Debit: {totalDebit.toFixed(2)} | Credit: {totalCredit.toFixed(2)}</div>
        <button type="submit" disabled={!canPost}>Post</button>
      </form>
      {message && <div style={{color:'green'}}>{message}</div>}
      {error && <div style={{color:'crimson'}}>{error}</div>}
    </div>
  )
}
