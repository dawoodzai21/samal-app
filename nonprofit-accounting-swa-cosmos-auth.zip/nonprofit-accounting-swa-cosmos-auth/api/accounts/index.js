const { getContainers } = require('../shared/cosmos')
const { getUser, requireRole } = require('../shared/auth')

module.exports = async function (context, req) {
  const method = (req.method || 'GET').toUpperCase()
  const user = getUser(req)
  const { accounts } = await getContainers()

  if (method === 'GET'){
    const { resources } = await accounts.items.query({ query: 'SELECT c.code, c.name, c.type, c.isActive FROM c' }).fetchAll()
    return { status: 200, body: resources || [] }
  }

  if (method === 'POST'){
    if (!requireRole(user, ['treasurer'])) return { status: 403, body: 'Forbidden' }
    const b = req.body || {}
    if (!b.code || !b.name || !b.type) return { status: 400, body: 'code, name, and type are required.' }

    const item = { id: String(b.code), code: String(b.code), name: String(b.name), type: String(b.type), isActive: b.isActive === false ? false : true, createdAt: new Date().toISOString() }

    try {
      const existing = await accounts.item(item.code, item.code).read()
      if (existing.resource) return { status: 409, body: 'Account code already exists.' }
    } catch (e) { }

    try {
      await accounts.items.create(item)
      return { status: 201, body: { ok: true } }
    } catch (e) {
      context.log.error(e)
      return { status: 500, body: 'Failed to create account.' }
    }
  }

  return { status: 405 }
}
