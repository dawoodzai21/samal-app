function parseClientPrincipal(headerValue){
  if (!headerValue) return null
  try{
    const json = Buffer.from(headerValue, 'base64').toString('utf8')
    const p = JSON.parse(json)
    return p
  }catch{ return null }
}

function getUser(req){
  const p = parseClientPrincipal(req.headers['x-ms-client-principal'] || req.headers['X-MS-CLIENT-PRINCIPAL'])
  if (!p) return { isAuthenticated: false, roles: [] }
  return { isAuthenticated: true, roles: p.userRoles || [], info: p }
}

function requireRole(user, needed){
  if (!user.isAuthenticated) return false
  if (user.roles.includes('administrator')) return true
  return needed.some(r => user.roles.includes(r))
}

module.exports = { getUser, requireRole }
