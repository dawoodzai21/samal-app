const { CosmosClient } = require('@azure/cosmos')

function requireEnv(name){
  const v = process.env[name]
  if (!v) throw new Error(`Missing environment variable: ${name}`)
  return v
}

const endpoint = () => requireEnv('COSMOS_DB_ENDPOINT')
const key = () => requireEnv('COSMOS_DB_KEY')
const databaseId = process.env.COSMOS_DB_DATABASE || 'np-accounting'

const client = new CosmosClient({ endpoint: endpoint(), key: key() })

async function ensureContainers(){
  const { database } = await client.databases.createIfNotExists({ id: databaseId })
  await database.containers.createIfNotExists({ id: 'Accounts', partitionKey: { paths: ['/code'] } })
  await database.containers.createIfNotExists({ id: 'Journal', partitionKey: { paths: ['/id'] } })
  await database.containers.createIfNotExists({ id: 'JournalLines', partitionKey: { paths: ['/journalId'] } })
  return database
}

async function getContainers(){
  const db = await ensureContainers()
  return {
    accounts: db.container('Accounts'),
    journal: db.container('Journal'),
    journalLines: db.container('JournalLines')
  }
}

module.exports = { getContainers, databaseId }
