const { getContainers } = require('../shared/cosmos')

module.exports = async function (context, req) {
  const { accounts, journalLines } = await getContainers()
  const asOf = (req.query && req.query.asOf) ? String(req.query.asOf) : new Date().toISOString().slice(0,10)

  const { resources: acctList } = await accounts.items.query('SELECT c.code, c.name, c.type FROM c').fetchAll()
  const acctMap = new Map(acctList.map(a => [a.code, a]))

  const { resources: lines } = await journalLines.items.query('SELECT * FROM c').fetchAll()
  const totals = new Map(Array.from(acctMap.keys()).map(k => [k, { debit:0, credit:0 }]))

  for (const e of lines){
    if (e.date && String(e.date) > asOf) continue
    const t = totals.get(e.accountCode) || { debit:0, credit:0 }
    t.debit += Number(e.debit||0)
    t.credit += Number(e.credit||0)
    totals.set(e.accountCode, t)
  }

  const rows = []
  for (const [code, t] of totals){
    const acct = acctMap.get(code)
    if (!acct) continue
    const normalDebit = (acct.type === 'Asset' || acct.type === 'Expense')
    const balance = normalDebit ? (t.debit - t.credit) : (t.credit - t.debit)
    rows.push({ accountCode: code, accountName: acct.name, debit: t.debit, credit: t.credit, balance })
  }

  rows.sort((a,b)=> a.accountCode.localeCompare(b.accountCode))
  return { status: 200, body: rows }
}
