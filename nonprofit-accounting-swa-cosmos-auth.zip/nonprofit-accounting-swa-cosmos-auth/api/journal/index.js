const { v4: uuidv4 } = require('uuid')
const { getContainers } = require('../shared/cosmos')
const { getUser, requireRole } = require('../shared/auth')

function validateJournalPayload(payload){
  if (!payload || !Array.isArray(payload.lines) || payload.lines.length < 2) return 'A journal entry must have at least 2 lines.'
  let debit = 0, credit = 0
  for (const [i, l] of payload.lines.entries()){
    const d = Number(l.debit||0), c = Number(l.credit||0)
    if ((d>0 && c>0) || (d<=0 && c<=0)) return `Line ${i+1}: provide either a debit OR a credit (> 0).`
    if (d<0 || c<0) return `Line ${i+1}: amounts must be >= 0.`
    if (!l.accountCode) return `Line ${i+1}: missing accountCode.`
    debit += d; credit += c
  }
  if (Math.abs(debit - credit) > 1e-6) return 'Debits must equal credits.'
  return null
}

module.exports = async function (context, req) {
  const user = getUser(req)
  if (!requireRole(user, ['treasurer'])) return { status: 403, body: 'Forbidden' }

  const error = validateJournalPayload(req.body)
  if (error) return { status: 400, body: error }

  const { accounts, journal, journalLines } = await getContainers()
  const { date, memo, lines } = req.body
  const isoDate = (date || new Date().toISOString().slice(0,10))
  const jeId = uuidv4()

  for (const l of lines){
    const { resource } = await accounts.item(l.accountCode, l.accountCode).read()
    if (!resource) return { status: 400, body: `Unknown account: ${l.accountCode}` }
  }

  await journal.items.create({ id: jeId, date: isoDate, memo: memo || '', createdAt: new Date().toISOString() })

  let idx = 0
  for (const l of lines){
    idx++
    await journalLines.items.create({ id: uuidv4(), journalId: jeId, seq: idx, date: isoDate, accountCode: String(l.accountCode), debit: Number(l.debit||0), credit: Number(l.credit||0), memo: l.memo || '' })
  }

  return { status: 201, body: { ok: true, journalId: jeId } }
}
